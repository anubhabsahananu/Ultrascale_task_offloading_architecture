// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "ximage_filter_engine.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XImage_filter_engine_CfgInitialize(XImage_filter_engine *InstancePtr, XImage_filter_engine_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XImage_filter_engine_Start(XImage_filter_engine *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XImage_filter_engine_ReadReg(InstancePtr->Control_BaseAddress, XIMAGE_FILTER_ENGINE_CONTROL_ADDR_AP_CTRL) & 0x80;
    XImage_filter_engine_WriteReg(InstancePtr->Control_BaseAddress, XIMAGE_FILTER_ENGINE_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XImage_filter_engine_IsDone(XImage_filter_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XImage_filter_engine_ReadReg(InstancePtr->Control_BaseAddress, XIMAGE_FILTER_ENGINE_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XImage_filter_engine_IsIdle(XImage_filter_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XImage_filter_engine_ReadReg(InstancePtr->Control_BaseAddress, XIMAGE_FILTER_ENGINE_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XImage_filter_engine_IsReady(XImage_filter_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XImage_filter_engine_ReadReg(InstancePtr->Control_BaseAddress, XIMAGE_FILTER_ENGINE_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XImage_filter_engine_EnableAutoRestart(XImage_filter_engine *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XImage_filter_engine_WriteReg(InstancePtr->Control_BaseAddress, XIMAGE_FILTER_ENGINE_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XImage_filter_engine_DisableAutoRestart(XImage_filter_engine *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XImage_filter_engine_WriteReg(InstancePtr->Control_BaseAddress, XIMAGE_FILTER_ENGINE_CONTROL_ADDR_AP_CTRL, 0);
}

void XImage_filter_engine_Set_width(XImage_filter_engine *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XImage_filter_engine_WriteReg(InstancePtr->Control_BaseAddress, XIMAGE_FILTER_ENGINE_CONTROL_ADDR_WIDTH_DATA, Data);
}

u32 XImage_filter_engine_Get_width(XImage_filter_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XImage_filter_engine_ReadReg(InstancePtr->Control_BaseAddress, XIMAGE_FILTER_ENGINE_CONTROL_ADDR_WIDTH_DATA);
    return Data;
}

void XImage_filter_engine_Set_height(XImage_filter_engine *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XImage_filter_engine_WriteReg(InstancePtr->Control_BaseAddress, XIMAGE_FILTER_ENGINE_CONTROL_ADDR_HEIGHT_DATA, Data);
}

u32 XImage_filter_engine_Get_height(XImage_filter_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XImage_filter_engine_ReadReg(InstancePtr->Control_BaseAddress, XIMAGE_FILTER_ENGINE_CONTROL_ADDR_HEIGHT_DATA);
    return Data;
}

void XImage_filter_engine_InterruptGlobalEnable(XImage_filter_engine *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XImage_filter_engine_WriteReg(InstancePtr->Control_BaseAddress, XIMAGE_FILTER_ENGINE_CONTROL_ADDR_GIE, 1);
}

void XImage_filter_engine_InterruptGlobalDisable(XImage_filter_engine *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XImage_filter_engine_WriteReg(InstancePtr->Control_BaseAddress, XIMAGE_FILTER_ENGINE_CONTROL_ADDR_GIE, 0);
}

void XImage_filter_engine_InterruptEnable(XImage_filter_engine *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XImage_filter_engine_ReadReg(InstancePtr->Control_BaseAddress, XIMAGE_FILTER_ENGINE_CONTROL_ADDR_IER);
    XImage_filter_engine_WriteReg(InstancePtr->Control_BaseAddress, XIMAGE_FILTER_ENGINE_CONTROL_ADDR_IER, Register | Mask);
}

void XImage_filter_engine_InterruptDisable(XImage_filter_engine *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XImage_filter_engine_ReadReg(InstancePtr->Control_BaseAddress, XIMAGE_FILTER_ENGINE_CONTROL_ADDR_IER);
    XImage_filter_engine_WriteReg(InstancePtr->Control_BaseAddress, XIMAGE_FILTER_ENGINE_CONTROL_ADDR_IER, Register & (~Mask));
}

void XImage_filter_engine_InterruptClear(XImage_filter_engine *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XImage_filter_engine_WriteReg(InstancePtr->Control_BaseAddress, XIMAGE_FILTER_ENGINE_CONTROL_ADDR_ISR, Mask);
}

u32 XImage_filter_engine_InterruptGetEnabled(XImage_filter_engine *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XImage_filter_engine_ReadReg(InstancePtr->Control_BaseAddress, XIMAGE_FILTER_ENGINE_CONTROL_ADDR_IER);
}

u32 XImage_filter_engine_InterruptGetStatus(XImage_filter_engine *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XImage_filter_engine_ReadReg(InstancePtr->Control_BaseAddress, XIMAGE_FILTER_ENGINE_CONTROL_ADDR_ISR);
}

