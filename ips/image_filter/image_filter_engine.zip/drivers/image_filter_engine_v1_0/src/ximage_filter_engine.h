// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XIMAGE_FILTER_ENGINE_H
#define XIMAGE_FILTER_ENGINE_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "ximage_filter_engine_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XImage_filter_engine_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XImage_filter_engine;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XImage_filter_engine_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XImage_filter_engine_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XImage_filter_engine_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XImage_filter_engine_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XImage_filter_engine_Initialize(XImage_filter_engine *InstancePtr, UINTPTR BaseAddress);
XImage_filter_engine_Config* XImage_filter_engine_LookupConfig(UINTPTR BaseAddress);
#else
int XImage_filter_engine_Initialize(XImage_filter_engine *InstancePtr, u16 DeviceId);
XImage_filter_engine_Config* XImage_filter_engine_LookupConfig(u16 DeviceId);
#endif
int XImage_filter_engine_CfgInitialize(XImage_filter_engine *InstancePtr, XImage_filter_engine_Config *ConfigPtr);
#else
int XImage_filter_engine_Initialize(XImage_filter_engine *InstancePtr, const char* InstanceName);
int XImage_filter_engine_Release(XImage_filter_engine *InstancePtr);
#endif

void XImage_filter_engine_Start(XImage_filter_engine *InstancePtr);
u32 XImage_filter_engine_IsDone(XImage_filter_engine *InstancePtr);
u32 XImage_filter_engine_IsIdle(XImage_filter_engine *InstancePtr);
u32 XImage_filter_engine_IsReady(XImage_filter_engine *InstancePtr);
void XImage_filter_engine_EnableAutoRestart(XImage_filter_engine *InstancePtr);
void XImage_filter_engine_DisableAutoRestart(XImage_filter_engine *InstancePtr);

void XImage_filter_engine_Set_width(XImage_filter_engine *InstancePtr, u32 Data);
u32 XImage_filter_engine_Get_width(XImage_filter_engine *InstancePtr);
void XImage_filter_engine_Set_height(XImage_filter_engine *InstancePtr, u32 Data);
u32 XImage_filter_engine_Get_height(XImage_filter_engine *InstancePtr);

void XImage_filter_engine_InterruptGlobalEnable(XImage_filter_engine *InstancePtr);
void XImage_filter_engine_InterruptGlobalDisable(XImage_filter_engine *InstancePtr);
void XImage_filter_engine_InterruptEnable(XImage_filter_engine *InstancePtr, u32 Mask);
void XImage_filter_engine_InterruptDisable(XImage_filter_engine *InstancePtr, u32 Mask);
void XImage_filter_engine_InterruptClear(XImage_filter_engine *InstancePtr, u32 Mask);
u32 XImage_filter_engine_InterruptGetEnabled(XImage_filter_engine *InstancePtr);
u32 XImage_filter_engine_InterruptGetStatus(XImage_filter_engine *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
