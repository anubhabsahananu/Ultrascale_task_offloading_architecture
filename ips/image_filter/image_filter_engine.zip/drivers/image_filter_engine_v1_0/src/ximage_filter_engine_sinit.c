// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "ximage_filter_engine.h"

extern XImage_filter_engine_Config XImage_filter_engine_ConfigTable[];

#ifdef SDT
XImage_filter_engine_Config *XImage_filter_engine_LookupConfig(UINTPTR BaseAddress) {
	XImage_filter_engine_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XImage_filter_engine_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XImage_filter_engine_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XImage_filter_engine_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XImage_filter_engine_Initialize(XImage_filter_engine *InstancePtr, UINTPTR BaseAddress) {
	XImage_filter_engine_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XImage_filter_engine_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XImage_filter_engine_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XImage_filter_engine_Config *XImage_filter_engine_LookupConfig(u16 DeviceId) {
	XImage_filter_engine_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XIMAGE_FILTER_ENGINE_NUM_INSTANCES; Index++) {
		if (XImage_filter_engine_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XImage_filter_engine_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XImage_filter_engine_Initialize(XImage_filter_engine *InstancePtr, u16 DeviceId) {
	XImage_filter_engine_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XImage_filter_engine_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XImage_filter_engine_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

