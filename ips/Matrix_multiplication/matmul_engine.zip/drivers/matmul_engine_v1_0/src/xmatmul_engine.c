// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xmatmul_engine.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XMatmul_engine_CfgInitialize(XMatmul_engine *InstancePtr, XMatmul_engine_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XMatmul_engine_Start(XMatmul_engine *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMatmul_engine_ReadReg(InstancePtr->Control_BaseAddress, XMATMUL_ENGINE_CONTROL_ADDR_AP_CTRL) & 0x80;
    XMatmul_engine_WriteReg(InstancePtr->Control_BaseAddress, XMATMUL_ENGINE_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XMatmul_engine_IsDone(XMatmul_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMatmul_engine_ReadReg(InstancePtr->Control_BaseAddress, XMATMUL_ENGINE_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XMatmul_engine_IsIdle(XMatmul_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMatmul_engine_ReadReg(InstancePtr->Control_BaseAddress, XMATMUL_ENGINE_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XMatmul_engine_IsReady(XMatmul_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMatmul_engine_ReadReg(InstancePtr->Control_BaseAddress, XMATMUL_ENGINE_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XMatmul_engine_EnableAutoRestart(XMatmul_engine *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMatmul_engine_WriteReg(InstancePtr->Control_BaseAddress, XMATMUL_ENGINE_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XMatmul_engine_DisableAutoRestart(XMatmul_engine *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMatmul_engine_WriteReg(InstancePtr->Control_BaseAddress, XMATMUL_ENGINE_CONTROL_ADDR_AP_CTRL, 0);
}

void XMatmul_engine_InterruptGlobalEnable(XMatmul_engine *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMatmul_engine_WriteReg(InstancePtr->Control_BaseAddress, XMATMUL_ENGINE_CONTROL_ADDR_GIE, 1);
}

void XMatmul_engine_InterruptGlobalDisable(XMatmul_engine *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMatmul_engine_WriteReg(InstancePtr->Control_BaseAddress, XMATMUL_ENGINE_CONTROL_ADDR_GIE, 0);
}

void XMatmul_engine_InterruptEnable(XMatmul_engine *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMatmul_engine_ReadReg(InstancePtr->Control_BaseAddress, XMATMUL_ENGINE_CONTROL_ADDR_IER);
    XMatmul_engine_WriteReg(InstancePtr->Control_BaseAddress, XMATMUL_ENGINE_CONTROL_ADDR_IER, Register | Mask);
}

void XMatmul_engine_InterruptDisable(XMatmul_engine *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMatmul_engine_ReadReg(InstancePtr->Control_BaseAddress, XMATMUL_ENGINE_CONTROL_ADDR_IER);
    XMatmul_engine_WriteReg(InstancePtr->Control_BaseAddress, XMATMUL_ENGINE_CONTROL_ADDR_IER, Register & (~Mask));
}

void XMatmul_engine_InterruptClear(XMatmul_engine *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMatmul_engine_WriteReg(InstancePtr->Control_BaseAddress, XMATMUL_ENGINE_CONTROL_ADDR_ISR, Mask);
}

u32 XMatmul_engine_InterruptGetEnabled(XMatmul_engine *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMatmul_engine_ReadReg(InstancePtr->Control_BaseAddress, XMATMUL_ENGINE_CONTROL_ADDR_IER);
}

u32 XMatmul_engine_InterruptGetStatus(XMatmul_engine *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMatmul_engine_ReadReg(InstancePtr->Control_BaseAddress, XMATMUL_ENGINE_CONTROL_ADDR_ISR);
}

