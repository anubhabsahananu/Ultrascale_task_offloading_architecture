// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XMATMUL_ENGINE_H
#define XMATMUL_ENGINE_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xmatmul_engine_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XMatmul_engine_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XMatmul_engine;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XMatmul_engine_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XMatmul_engine_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XMatmul_engine_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XMatmul_engine_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XMatmul_engine_Initialize(XMatmul_engine *InstancePtr, UINTPTR BaseAddress);
XMatmul_engine_Config* XMatmul_engine_LookupConfig(UINTPTR BaseAddress);
#else
int XMatmul_engine_Initialize(XMatmul_engine *InstancePtr, u16 DeviceId);
XMatmul_engine_Config* XMatmul_engine_LookupConfig(u16 DeviceId);
#endif
int XMatmul_engine_CfgInitialize(XMatmul_engine *InstancePtr, XMatmul_engine_Config *ConfigPtr);
#else
int XMatmul_engine_Initialize(XMatmul_engine *InstancePtr, const char* InstanceName);
int XMatmul_engine_Release(XMatmul_engine *InstancePtr);
#endif

void XMatmul_engine_Start(XMatmul_engine *InstancePtr);
u32 XMatmul_engine_IsDone(XMatmul_engine *InstancePtr);
u32 XMatmul_engine_IsIdle(XMatmul_engine *InstancePtr);
u32 XMatmul_engine_IsReady(XMatmul_engine *InstancePtr);
void XMatmul_engine_EnableAutoRestart(XMatmul_engine *InstancePtr);
void XMatmul_engine_DisableAutoRestart(XMatmul_engine *InstancePtr);


void XMatmul_engine_InterruptGlobalEnable(XMatmul_engine *InstancePtr);
void XMatmul_engine_InterruptGlobalDisable(XMatmul_engine *InstancePtr);
void XMatmul_engine_InterruptEnable(XMatmul_engine *InstancePtr, u32 Mask);
void XMatmul_engine_InterruptDisable(XMatmul_engine *InstancePtr, u32 Mask);
void XMatmul_engine_InterruptClear(XMatmul_engine *InstancePtr, u32 Mask);
u32 XMatmul_engine_InterruptGetEnabled(XMatmul_engine *InstancePtr);
u32 XMatmul_engine_InterruptGetStatus(XMatmul_engine *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
