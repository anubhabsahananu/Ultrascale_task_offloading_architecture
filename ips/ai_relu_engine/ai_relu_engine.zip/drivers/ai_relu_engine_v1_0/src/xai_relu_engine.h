// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XAI_RELU_ENGINE_H
#define XAI_RELU_ENGINE_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xai_relu_engine_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XAi_relu_engine_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XAi_relu_engine;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XAi_relu_engine_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XAi_relu_engine_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XAi_relu_engine_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XAi_relu_engine_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XAi_relu_engine_Initialize(XAi_relu_engine *InstancePtr, UINTPTR BaseAddress);
XAi_relu_engine_Config* XAi_relu_engine_LookupConfig(UINTPTR BaseAddress);
#else
int XAi_relu_engine_Initialize(XAi_relu_engine *InstancePtr, u16 DeviceId);
XAi_relu_engine_Config* XAi_relu_engine_LookupConfig(u16 DeviceId);
#endif
int XAi_relu_engine_CfgInitialize(XAi_relu_engine *InstancePtr, XAi_relu_engine_Config *ConfigPtr);
#else
int XAi_relu_engine_Initialize(XAi_relu_engine *InstancePtr, const char* InstanceName);
int XAi_relu_engine_Release(XAi_relu_engine *InstancePtr);
#endif

void XAi_relu_engine_Start(XAi_relu_engine *InstancePtr);
u32 XAi_relu_engine_IsDone(XAi_relu_engine *InstancePtr);
u32 XAi_relu_engine_IsIdle(XAi_relu_engine *InstancePtr);
u32 XAi_relu_engine_IsReady(XAi_relu_engine *InstancePtr);
void XAi_relu_engine_EnableAutoRestart(XAi_relu_engine *InstancePtr);
void XAi_relu_engine_DisableAutoRestart(XAi_relu_engine *InstancePtr);

void XAi_relu_engine_Set_size(XAi_relu_engine *InstancePtr, u32 Data);
u32 XAi_relu_engine_Get_size(XAi_relu_engine *InstancePtr);

void XAi_relu_engine_InterruptGlobalEnable(XAi_relu_engine *InstancePtr);
void XAi_relu_engine_InterruptGlobalDisable(XAi_relu_engine *InstancePtr);
void XAi_relu_engine_InterruptEnable(XAi_relu_engine *InstancePtr, u32 Mask);
void XAi_relu_engine_InterruptDisable(XAi_relu_engine *InstancePtr, u32 Mask);
void XAi_relu_engine_InterruptClear(XAi_relu_engine *InstancePtr, u32 Mask);
u32 XAi_relu_engine_InterruptGetEnabled(XAi_relu_engine *InstancePtr);
u32 XAi_relu_engine_InterruptGetStatus(XAi_relu_engine *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
