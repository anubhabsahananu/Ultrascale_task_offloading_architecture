// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xai_relu_engine.h"

extern XAi_relu_engine_Config XAi_relu_engine_ConfigTable[];

#ifdef SDT
XAi_relu_engine_Config *XAi_relu_engine_LookupConfig(UINTPTR BaseAddress) {
	XAi_relu_engine_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XAi_relu_engine_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XAi_relu_engine_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XAi_relu_engine_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XAi_relu_engine_Initialize(XAi_relu_engine *InstancePtr, UINTPTR BaseAddress) {
	XAi_relu_engine_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XAi_relu_engine_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XAi_relu_engine_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XAi_relu_engine_Config *XAi_relu_engine_LookupConfig(u16 DeviceId) {
	XAi_relu_engine_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XAI_RELU_ENGINE_NUM_INSTANCES; Index++) {
		if (XAi_relu_engine_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XAi_relu_engine_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XAi_relu_engine_Initialize(XAi_relu_engine *InstancePtr, u16 DeviceId) {
	XAi_relu_engine_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XAi_relu_engine_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XAi_relu_engine_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

