// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xai_relu_engine.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XAi_relu_engine_CfgInitialize(XAi_relu_engine *InstancePtr, XAi_relu_engine_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XAi_relu_engine_Start(XAi_relu_engine *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAi_relu_engine_ReadReg(InstancePtr->Control_BaseAddress, XAI_RELU_ENGINE_CONTROL_ADDR_AP_CTRL) & 0x80;
    XAi_relu_engine_WriteReg(InstancePtr->Control_BaseAddress, XAI_RELU_ENGINE_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XAi_relu_engine_IsDone(XAi_relu_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAi_relu_engine_ReadReg(InstancePtr->Control_BaseAddress, XAI_RELU_ENGINE_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XAi_relu_engine_IsIdle(XAi_relu_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAi_relu_engine_ReadReg(InstancePtr->Control_BaseAddress, XAI_RELU_ENGINE_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XAi_relu_engine_IsReady(XAi_relu_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAi_relu_engine_ReadReg(InstancePtr->Control_BaseAddress, XAI_RELU_ENGINE_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XAi_relu_engine_EnableAutoRestart(XAi_relu_engine *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAi_relu_engine_WriteReg(InstancePtr->Control_BaseAddress, XAI_RELU_ENGINE_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XAi_relu_engine_DisableAutoRestart(XAi_relu_engine *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAi_relu_engine_WriteReg(InstancePtr->Control_BaseAddress, XAI_RELU_ENGINE_CONTROL_ADDR_AP_CTRL, 0);
}

void XAi_relu_engine_Set_size(XAi_relu_engine *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAi_relu_engine_WriteReg(InstancePtr->Control_BaseAddress, XAI_RELU_ENGINE_CONTROL_ADDR_SIZE_DATA, Data);
}

u32 XAi_relu_engine_Get_size(XAi_relu_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAi_relu_engine_ReadReg(InstancePtr->Control_BaseAddress, XAI_RELU_ENGINE_CONTROL_ADDR_SIZE_DATA);
    return Data;
}

void XAi_relu_engine_InterruptGlobalEnable(XAi_relu_engine *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAi_relu_engine_WriteReg(InstancePtr->Control_BaseAddress, XAI_RELU_ENGINE_CONTROL_ADDR_GIE, 1);
}

void XAi_relu_engine_InterruptGlobalDisable(XAi_relu_engine *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAi_relu_engine_WriteReg(InstancePtr->Control_BaseAddress, XAI_RELU_ENGINE_CONTROL_ADDR_GIE, 0);
}

void XAi_relu_engine_InterruptEnable(XAi_relu_engine *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XAi_relu_engine_ReadReg(InstancePtr->Control_BaseAddress, XAI_RELU_ENGINE_CONTROL_ADDR_IER);
    XAi_relu_engine_WriteReg(InstancePtr->Control_BaseAddress, XAI_RELU_ENGINE_CONTROL_ADDR_IER, Register | Mask);
}

void XAi_relu_engine_InterruptDisable(XAi_relu_engine *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XAi_relu_engine_ReadReg(InstancePtr->Control_BaseAddress, XAI_RELU_ENGINE_CONTROL_ADDR_IER);
    XAi_relu_engine_WriteReg(InstancePtr->Control_BaseAddress, XAI_RELU_ENGINE_CONTROL_ADDR_IER, Register & (~Mask));
}

void XAi_relu_engine_InterruptClear(XAi_relu_engine *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAi_relu_engine_WriteReg(InstancePtr->Control_BaseAddress, XAI_RELU_ENGINE_CONTROL_ADDR_ISR, Mask);
}

u32 XAi_relu_engine_InterruptGetEnabled(XAi_relu_engine *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAi_relu_engine_ReadReg(InstancePtr->Control_BaseAddress, XAI_RELU_ENGINE_CONTROL_ADDR_IER);
}

u32 XAi_relu_engine_InterruptGetStatus(XAi_relu_engine *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAi_relu_engine_ReadReg(InstancePtr->Control_BaseAddress, XAI_RELU_ENGINE_CONTROL_ADDR_ISR);
}

