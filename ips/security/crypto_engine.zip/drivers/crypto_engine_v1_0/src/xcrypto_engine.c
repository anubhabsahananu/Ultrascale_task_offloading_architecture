// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xcrypto_engine.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XCrypto_engine_CfgInitialize(XCrypto_engine *InstancePtr, XCrypto_engine_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XCrypto_engine_Start(XCrypto_engine *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCrypto_engine_ReadReg(InstancePtr->Control_BaseAddress, XCRYPTO_ENGINE_CONTROL_ADDR_AP_CTRL) & 0x80;
    XCrypto_engine_WriteReg(InstancePtr->Control_BaseAddress, XCRYPTO_ENGINE_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XCrypto_engine_IsDone(XCrypto_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCrypto_engine_ReadReg(InstancePtr->Control_BaseAddress, XCRYPTO_ENGINE_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XCrypto_engine_IsIdle(XCrypto_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCrypto_engine_ReadReg(InstancePtr->Control_BaseAddress, XCRYPTO_ENGINE_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XCrypto_engine_IsReady(XCrypto_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCrypto_engine_ReadReg(InstancePtr->Control_BaseAddress, XCRYPTO_ENGINE_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XCrypto_engine_EnableAutoRestart(XCrypto_engine *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCrypto_engine_WriteReg(InstancePtr->Control_BaseAddress, XCRYPTO_ENGINE_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XCrypto_engine_DisableAutoRestart(XCrypto_engine *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCrypto_engine_WriteReg(InstancePtr->Control_BaseAddress, XCRYPTO_ENGINE_CONTROL_ADDR_AP_CTRL, 0);
}

void XCrypto_engine_Set_key(XCrypto_engine *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCrypto_engine_WriteReg(InstancePtr->Control_BaseAddress, XCRYPTO_ENGINE_CONTROL_ADDR_KEY_DATA, Data);
}

u32 XCrypto_engine_Get_key(XCrypto_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCrypto_engine_ReadReg(InstancePtr->Control_BaseAddress, XCRYPTO_ENGINE_CONTROL_ADDR_KEY_DATA);
    return Data;
}

void XCrypto_engine_Set_size(XCrypto_engine *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCrypto_engine_WriteReg(InstancePtr->Control_BaseAddress, XCRYPTO_ENGINE_CONTROL_ADDR_SIZE_DATA, Data);
}

u32 XCrypto_engine_Get_size(XCrypto_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCrypto_engine_ReadReg(InstancePtr->Control_BaseAddress, XCRYPTO_ENGINE_CONTROL_ADDR_SIZE_DATA);
    return Data;
}

void XCrypto_engine_Set_mode(XCrypto_engine *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCrypto_engine_WriteReg(InstancePtr->Control_BaseAddress, XCRYPTO_ENGINE_CONTROL_ADDR_MODE_DATA, Data);
}

u32 XCrypto_engine_Get_mode(XCrypto_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCrypto_engine_ReadReg(InstancePtr->Control_BaseAddress, XCRYPTO_ENGINE_CONTROL_ADDR_MODE_DATA);
    return Data;
}

void XCrypto_engine_InterruptGlobalEnable(XCrypto_engine *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCrypto_engine_WriteReg(InstancePtr->Control_BaseAddress, XCRYPTO_ENGINE_CONTROL_ADDR_GIE, 1);
}

void XCrypto_engine_InterruptGlobalDisable(XCrypto_engine *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCrypto_engine_WriteReg(InstancePtr->Control_BaseAddress, XCRYPTO_ENGINE_CONTROL_ADDR_GIE, 0);
}

void XCrypto_engine_InterruptEnable(XCrypto_engine *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XCrypto_engine_ReadReg(InstancePtr->Control_BaseAddress, XCRYPTO_ENGINE_CONTROL_ADDR_IER);
    XCrypto_engine_WriteReg(InstancePtr->Control_BaseAddress, XCRYPTO_ENGINE_CONTROL_ADDR_IER, Register | Mask);
}

void XCrypto_engine_InterruptDisable(XCrypto_engine *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XCrypto_engine_ReadReg(InstancePtr->Control_BaseAddress, XCRYPTO_ENGINE_CONTROL_ADDR_IER);
    XCrypto_engine_WriteReg(InstancePtr->Control_BaseAddress, XCRYPTO_ENGINE_CONTROL_ADDR_IER, Register & (~Mask));
}

void XCrypto_engine_InterruptClear(XCrypto_engine *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCrypto_engine_WriteReg(InstancePtr->Control_BaseAddress, XCRYPTO_ENGINE_CONTROL_ADDR_ISR, Mask);
}

u32 XCrypto_engine_InterruptGetEnabled(XCrypto_engine *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XCrypto_engine_ReadReg(InstancePtr->Control_BaseAddress, XCRYPTO_ENGINE_CONTROL_ADDR_IER);
}

u32 XCrypto_engine_InterruptGetStatus(XCrypto_engine *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XCrypto_engine_ReadReg(InstancePtr->Control_BaseAddress, XCRYPTO_ENGINE_CONTROL_ADDR_ISR);
}

