// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xcrypto_engine.h"

extern XCrypto_engine_Config XCrypto_engine_ConfigTable[];

#ifdef SDT
XCrypto_engine_Config *XCrypto_engine_LookupConfig(UINTPTR BaseAddress) {
	XCrypto_engine_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XCrypto_engine_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XCrypto_engine_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XCrypto_engine_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XCrypto_engine_Initialize(XCrypto_engine *InstancePtr, UINTPTR BaseAddress) {
	XCrypto_engine_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XCrypto_engine_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XCrypto_engine_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XCrypto_engine_Config *XCrypto_engine_LookupConfig(u16 DeviceId) {
	XCrypto_engine_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XCRYPTO_ENGINE_NUM_INSTANCES; Index++) {
		if (XCrypto_engine_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XCrypto_engine_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XCrypto_engine_Initialize(XCrypto_engine *InstancePtr, u16 DeviceId) {
	XCrypto_engine_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XCrypto_engine_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XCrypto_engine_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

